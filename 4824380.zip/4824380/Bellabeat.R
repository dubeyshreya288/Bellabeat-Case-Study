---
title: "Bellabeat Case Study"
output: html_notebook
---

# Summary

a hightech company **Bellabeat** that manufactures health focus smart products founded by **Urska Srsen** and **Sando Mur** collecting data on activity, sleep, stress and reproductive health has allowded bellabeat to empower women with knowledge their own health and habits since 2013.

# Stakeholder
 
1.Urska Srsen - Cofounder and Chief Creative
2.Sando Mur   - Cofounder and Mathematician 
3.Bellabeat's Marketing Analytics Team
